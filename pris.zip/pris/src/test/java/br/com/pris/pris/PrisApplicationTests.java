package br.com.pris.pris;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrisApplicationTests {

	@Test
	void contextLoads() {
	}

}
